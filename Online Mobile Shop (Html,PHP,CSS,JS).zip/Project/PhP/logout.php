<?php
include('database.php');
session_start();
$sql="DELETE FROM `chart` WHERE `Email` = '".$_SESSION['user']."'";
updateSQL($sql);
unset($_COOKIE['permission']);
$_SESSION["flag"]=null;
$_SESSION['user'] =null;
$_SESSION['type'] =null;
header("Location:homepage");
?>