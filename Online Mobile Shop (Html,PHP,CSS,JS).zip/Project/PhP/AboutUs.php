<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
	<link rel="stylesheet" type="text/css" href="../CSS/AboutUs.css"/>
</head>
<body style="background-color: white;" >
	<?php 
include("Home2.php");
?>
 <div class="about1 clear template1">
	<h1>ABOUT US</h1>
	<p>
		This is an ultimate shopping destination where you can shop the widest selection of smart and feature phones. We also delevered the purchased phones to the customers within a short time. We offer free returns and various payment method including cash on delevery, online payments, swipe on delevery and BKash with affordable price and quality smart phones. Follw us on facebook & twitter to be updated with our latest phones. For more information contact with <a href="mailto:sri.subrata.saha@gmail.com">Subroto</a> and <a href="mailto:sshihabb007@gmail.com">Shihab</a>. 

	</p>

	<center> <img src="../Image/right_choice.png"></center>
	<h2 style="text-align: center;color: black;">Helps You Make the Right Choice</h2>

	<ul>
		<li>Best shopping experience</li>
		<li>Trusted online shopping platform</li>
		<li>Fastest Delivery service</li>
		<li>Genuine products only</li>
		<li>Free returns</li>
	</ul>

</div>


</body>
</html>
