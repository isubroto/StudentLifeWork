﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Access;

namespace WindowsFormsApplication8
{
    public partial class ProductReport : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        UserOperation uop = new UserOperation();
        DataTable dt1 = new DataTable();
        public ProductReport()
        {
            InitializeComponent();
            if (Login.isLogin == true)
            {
                label1.Text = "Logout";
                label6.Visible = true;
            }
            else
            {
                label6.Visible = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Hide();
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Desktop d1 = new Desktop();
            this.Hide();
            d1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Laptop l1 = new Laptop();
            this.Hide();
            l1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mobile m1 = new Mobile();
            this.Hide();
            m1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tablate l1 = new Tablate();
            this.Hide();
            l1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Login")
            {
                Login l1 = new Login();
                this.Hide();
                l1.Show();
            }
            else if (label1.Text == "Logout")
            {
                this.label1.Text = "Login";
                Login.isLogin = false;
                Login.logintype = null;
                label6.Visible = false;
                button1.Visible = false;
                Form1 f1 = new Form1();
                this.Hide();
                f1.Show();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminPanel ap = new AdminPanel();
            this.Hide();
            ap.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Chart c = new Chart();
            this.Hide();
            c.Show();
        }

        private void SaleReport_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = uop.GetCatagory();
            int rc = dt.Rows.Count;
            comboBox2.Items.Clear();
            for (int i = 0; i < rc; i++)
            {
                comboBox2.Items.Add(dt.Rows[i][0]);
            }
            

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            if (comboBox2.Text == "Mobile")
            {
                dt = uop.GetReview();
                dataGridView1.DataSource = dt;
            }
            else if (comboBox2.Text == "Tablet")
            {
                dt = uop.GetTabletPrice();
                dataGridView1.DataSource = dt;
            }
            else if (comboBox2.Text == "Laptop")
            {
                dt = uop.GetLaptopPrice();
                dataGridView1.DataSource = dt;
            }
            else if (comboBox2.Text == "Desktop")
            {
                label5.Visible = true;
                comboBox3.Visible = true;
                dt = uop.GetParts();
                int rc = dt.Rows.Count;
                comboBox3.Items.Clear();
                for (int i = 0; i < rc; i++)
                {
                    comboBox3.Items.Add(dt.Rows[i][0]);
                }

            }
            else
            {
                label5.Visible = false;
                comboBox3.Visible = false;
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            if(comboBox3.Text=="HDD")
            {
                dt = uop.GetHDD();
                dataGridView1.DataSource = dt;
            }
            else if (comboBox3.Text == "RAM")
            {
                dt = uop.GetRam();
                dataGridView1.DataSource = dt;
            }
            else if(comboBox3.Text=="Processor")
            {
                dt = uop.GetProcessor();
                dataGridView1.DataSource = dt;
            }
            else if(comboBox3.Text=="MotherBoard")
            {
                dt = uop.GetMotherBoard();
                dataGridView1.DataSource = dt;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Search s = new Search();
            if (comboBox1.Text == "Mobile")
            {
                dt1 = uop.SearchMobile(textBox1.Text);
                s.ReciveData(dt1, comboBox1.Text);
                this.Hide();
                s.Show();
            }
            else if (comboBox1.Text == "Laptop")
            {
                dt1 = uop.SearchLaptop(textBox1.Text);
                s.ReciveData(dt1, comboBox1.Text);
                this.Hide();
                s.Show();
            }
            else if (comboBox1.Text == "Tablet")
            {
                dt1 = uop.SearchTablet(textBox1.Text);
                s.ReciveData(dt1, comboBox1.Text);
                this.Hide();
                s.Show();
            }
            else if (comboBox1.Text == "HDD")
            {
                dt1 = uop.SearchHDD(textBox1.Text);
                s.ReciveData(dt1, comboBox1.Text);
                this.Hide();
                s.Show();
            }
            else if (comboBox1.Text == "RAM")
            {
                dt1 = uop.SearchRAM(textBox1.Text);
                s.ReciveData(dt1, comboBox1.Text);
                this.Hide();
                s.Show();
            }
            else if (comboBox1.Text == "Processor")
            {
                dt1 = uop.SearchProcessor(textBox1.Text);
                s.ReciveData(dt1, comboBox1.Text);
            }
            else if (comboBox1.Text == "MotherBoard")
            {
                dt1 = uop.SearchMotherBoard(textBox1.Text);
                s.ReciveData(dt1, comboBox1.Text);
            }
            else
                MessageBox.Show("please Select a Catagory");
        }
    }
}
