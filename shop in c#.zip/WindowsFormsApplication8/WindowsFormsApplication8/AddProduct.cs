﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Access;
using Business_Emplementation;
using System.IO;

namespace WindowsFormsApplication8
{
    public partial class AddProduct : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        UserOperation uop = new UserOperation();
        LaptopInformation linfo = new LaptopInformation();
        MobileInformation mtinfo = new MobileInformation();
        TabletInformation tinfo = new TabletInformation();
        HDDInformation hinfo = new HDDInformation();
        OpenFileDialog f = new OpenFileDialog();
        RAMInformation rinfo = new RAMInformation();
        ProcessorInformation pinfo = new ProcessorInformation();
        MothetboardInformation mbinfo = new MothetboardInformation();
        string pic;

        public AddProduct()
        {
            InitializeComponent();
            if(Login.isLogin==true)
            {
                label1.Text = "Logout";
                label6.Visible = true;
            }
            else
            {
                label6.Visible = false;
            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Desktop d1 = new Desktop();
            this.Hide();
            d1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Laptop l1 = new Laptop();
            this.Hide();
            l1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mobile m1 = new Mobile();
            this.Hide();
            m1.Show();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminPanel t1 = new AdminPanel();
            this.Hide();
            t1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Login")
            {
                Login l1 = new Login();
                this.Hide();
                l1.Show();
            }
            else if (label1.Text == "Logout")
            {
                this.label1.Text = "Login";
                Login.isLogin = false;
                Login.logintype = null;
                label6.Visible = false;
                Form1 f1 = new Form1();
                this.Hide();
                f1.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Chart c = new Chart();
            this.Hide();
            c.Show();
        }

        private void AddProduct_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = uop.GetCatagory();
            int rc = dt.Rows.Count;
            comboBox2.Items.Clear();
            for (int i=0; i<rc;i++)
            {
                comboBox2.Items.Add(dt.Rows[i][0]);
            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox2.Text=="Desktop")
            {
                label5.Visible = true;
                comboBox3.Visible = true;
                DataTable dt = new DataTable();
                dt = uop.GetParts();
                int rc = dt.Rows.Count;
                comboBox3.Items.Clear();
                for(int i=0;i<rc;i++)
                {
                    comboBox3.Items.Add(dt.Rows[i][0]);
                }
                
            }
            else
            {
                label5.Visible = false;
                comboBox3.Visible = false;
            }
            if (comboBox2.Text == "Mobile" || comboBox2.Text == "Tablet")
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible  = l20.Visible =  true;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = t20.Visible =  true;
                button10.Visible = true;
                l1.Text = "Product Id:";
                l2.Text = "Model:";
                l3.Text = "Display Size:";
                l4.Text = "Tecnology:";
                l5.Text = "Display Type:";
                l6.Text = "USB:";
                l7.Text = "Battery:";
                l8.Text = "Memory:";
                l9.Text = "Conectivity:";
                l12.Text = "Video:";
                l13.Text = "OS:";
                l14.Text = "CPU";
                l15.Text = "GPU";
                l16.Text = "ChipSet";
                l17.Text = "Saling Price";
                l18.Text = "Brand Id";
                l19.Text = "Quantity";
                l20.Text = "Buing Price";


            }
            else if(comboBox2.Text=="Laptop")
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible = l20.Visible = true;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = t20.Visible = true;
                l1.Text = "Product Id:";
                l2.Text = "Model:";
                l3.Text = "Display Size:";
                l4.Text = "Processor:";
                l5.Text = "HDD:";
                l6.Text = "USB:";
                l7.Text = "Battery:";
                l8.Text = "RAM:";
                l9.Text = "Network:";
                l12.Text = "RAM Type:";
                l13.Text = "OS:";
                l14.Text = "SDD";
                l15.Text = "Optical Device";
                l16.Text = "ClockSpeed";
                l17.Text = "Saling Price";
                l18.Text = "Brand Id";
                l19.Text = "Quantity";
                l20.Text = "Buying Price";
                button10.Visible = true;
            }
            else
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible = l20.Visible = false;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = t20.Visible = false;
                button10.Visible = false;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                f.InitialDirectory = "C:/Picture/";
                f.Filter = "All Files|*.*|JPEGs|*.jpg|Bitamps|*.bmp|GIFs|*.gif";
                f.Multiselect = false;
                f.FilterIndex = 2;
                if (f.ShowDialog() == DialogResult.OK)
                {
                    pictureBox2.Image = Image.FromFile(f.FileName);
                    if (f.CheckFileExists)
                    {
                        string path = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
                        string name = Path.GetFileName(f.FileName);
                        path1.Text = f.FileName;
                        File.Copy(f.FileName, path + "\\Picture\\" + name);
                        pic= "\\Picture\\" + name;
                    }

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("This file name is already exist");
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox3.Text=="HDD")
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible = l20.Visible = false;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = t20.Visible = false;
                button10.Visible = false;
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible  =l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = true;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = true;
                l1.Text = "Product Id:";
                l2.Text = "Model:";
                l3.Text = "Brand:";
                l4.Text = "Type";
                l5.Text = "RPM:";
                l12.Text = "Capacity:";
                l13.Text = "Saling Price";
                l14.Text = "Parts Id";
                l15.Text = "Quantity";
                l16.Text = "Buying Price";
                button10.Visible = true;
            }
            else if(comboBox3.Text=="RAM")
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible = l20.Visible = false;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = t20.Visible = false;
                button10.Visible = false;
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible  = l12.Visible = l13.Visible = l14.Visible = l15.Visible = true;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible  = t12.Visible = t13.Visible = t14.Visible = t15.Visible = true;
                l1.Text = "Product Id:";
                l2.Text = "Model:";
                l3.Text = "Bus Speed:";
                l4.Text = "Type:";
                l5.Text = "Parts Id:";
                l12.Text = "Capacity:";
                l13.Text = "Saling Price:";
                l14.Text = "Brand:";
                l15.Text = "Quantity:";
                l16.Text = "Buying Price";
                button10.Visible = true;
            }
            else if(comboBox3.Text== "Processor")
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible = l20.Visible = false;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = t20.Visible = false;
                button10.Visible = false;
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = true;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = true;
                l1.Text = "Product Id:";
                l2.Text = "Model:";
                l3.Text = "Genaration:";
                l4.Text = "Number Of Core:";
                l5.Text = "Cache Memory:";
                l12.Text = "Parts Id";
                l13.Text = "Turbo:";
                l14.Text = "Saling Price";
                l15.Text = "Brand";
                l16.Text = "Quantity";
                l17.Text = "Buying Price";
                button10.Visible = true;
            }
            else if(comboBox3.Text== "MotherBoard")
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible = true;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = true;
                l1.Text = "Product Id:";
                l2.Text = "Model:";
                l3.Text = "CPU Socket:";
                l4.Text = "Graphic:";
                l5.Text = "Audio ChipSet:";
                l6.Text = "VGAPort:";
                l7.Text = "Bios Type:";
                l8.Text = "Bios Model:";
                l9.Text = "Supported Cpu:";
                l12.Text = "RAM Type:";
                l13.Text = "RAM Max:";
                l14.Text = "LAN ChipSet";
                l15.Text = "USB";
                l16.Text = "Saling Price";
                l17.Text = "Parts Id";
                l18.Text = "Quantity";
                l19.Text = "Buying Price";
                button10.Visible = true;
            }
            else
            {
                l1.Visible = l2.Visible = l3.Visible = l4.Visible = l5.Visible = l6.Visible = l7.Visible = l8.Visible = l9.Visible = l12.Visible = l13.Visible = l14.Visible = l15.Visible = l16.Visible = l17.Visible = l18.Visible = l19.Visible = l20.Visible = false;
                t1.Visible = t2.Visible = t3.Visible = t4.Visible = t5.Visible = t6.Visible = t7.Visible = t8.Visible = t9.Visible = t12.Visible = t13.Visible = t14.Visible = t15.Visible = t16.Visible = t17.Visible = t18.Visible = t19.Visible = t20.Visible = false;
                button10.Visible = false;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox2.Text == "Mobile")
                {
                    mtinfo.ProductId = Convert.ToInt32(t1.Text);
                    mtinfo.Model = t2.Text;
                    mtinfo.DsplaySize = t3.Text;
                    mtinfo.Tecnology = t4.Text;
                    mtinfo.DisplayType = t5.Text;
                    mtinfo.USB = l6.Text;
                    mtinfo.Battery = t7.Text;
                    mtinfo.Memory = t8.Text;
                    mtinfo.Conectivity = t9.Text;
                    mtinfo.Video = t12.Text;
                    mtinfo.OS = t13.Text;
                    mtinfo.CPU = t14.Text;
                    mtinfo.GPU = t15.Text;
                    mtinfo.ChipSet = t16.Text;
                    mtinfo.Price = Convert.ToInt32(t17.Text);
                    mtinfo.BuyPrice = Convert.ToInt32(t19.Text);
                    mtinfo.Brandid = Convert.ToInt32(t18.Text);
                    mtinfo.Quantity = Convert.ToInt32(t19.Text);
                    int rc = uop.InsertMobileFeature(mtinfo);
                    mtinfo.Picture = pic;
                    if (rc > 0)
                    {
                        MessageBox.Show("Product added");
                    }
                }
                else if (comboBox2.Text == "Tablet")
                {
                    tinfo.ProductId = Convert.ToInt32(t1.Text);
                    tinfo.Model = t2.Text;
                    tinfo.DsplaySize = t3.Text;
                    tinfo.Tecnology = t4.Text;
                    tinfo.DisplayType = t5.Text;
                    tinfo.USB = l6.Text;
                    tinfo.Battery = t7.Text;
                    tinfo.Memory = t8.Text;
                    tinfo.Conectivity = t9.Text;
                    tinfo.Video = t12.Text;
                    tinfo.OS = t13.Text;
                    tinfo.CPU = t14.Text;
                    tinfo.GPU = t15.Text;
                    tinfo.ChipSet = t16.Text;
                    tinfo.Price = Convert.ToInt32(t17.Text);
                    tinfo.BuyPrice = Convert.ToInt32(t19.Text);
                    tinfo.Brandid = Convert.ToInt32(t18.Text);
                    tinfo.Quantity = Convert.ToInt32(t19.Text);
                    tinfo.Picture = pic;
                    int rc = uop.InsertTabletFeature(tinfo);
                    if (rc > 0)
                    {
                        MessageBox.Show("Product added");
                    }
                }
                else if (comboBox2.Text=="Desktop")
                {
                    if (comboBox3.Text == "HDD")
                    {
                        hinfo.ProductId = Convert.ToInt32(l1.Text);
                        hinfo.Model = t2.Text;
                        hinfo.Brand = t3.Text;
                        hinfo.Type = t4.Text;
                        hinfo.RPM = t5.Text;
                        hinfo.Capacity = t12.Text;
                        hinfo.Price = Convert.ToInt32(t13.Text);
                        hinfo.BuyPrice = Convert.ToInt32(t16.Text);
                        hinfo.PartsId = Convert.ToInt32(t14.Text);
                        hinfo.Qantuty = Convert.ToInt32(t15.Text);
                        hinfo.Picture = pic;
                        int rc = uop.InsertHDDFeature(hinfo);
                        if (rc > 0)
                        {
                            MessageBox.Show("Product Added");
                        }
                        else if (comboBox3.Text == "RAM")
                        {
                            rinfo.ProductId = Convert.ToInt32(t1.Text);
                            rinfo.Model = t2.Text;
                            rinfo.BusSpeed = t3.Text;
                            rinfo.Type = t4.Text;
                            rinfo.PartsId = Convert.ToInt32(t5.Text);
                            rinfo.Capacity = t12.Text;
                            rinfo.Price = Convert.ToInt32(t13.Text);
                            rinfo.Brand = t14.Text;
                            rinfo.Qualtity = Convert.ToInt32(t15.Text);
                            rinfo.BuyPrice = Convert.ToInt32(t16.Text);
                            rinfo.Picure = pic;
                            int rc1 = uop.InsertRAMFeature(rinfo);
                            if (rc1 > 0)
                            {
                                MessageBox.Show("Product Added");
                            }
                        }
                        else if(comboBox3.Text=="Processor")
                        {
                            pinfo.ProductId = Convert.ToInt32(t1.Text);
                            pinfo.Model = t2.Text;
                            pinfo.Genaration = t3.Text;
                            pinfo.NumberOfCore = t4.Text;
                            pinfo.CashMemory = t5.Text;
                            pinfo.PartsId = Convert.ToInt32(t12.Text);
                            pinfo.Turbo = t13.Text;
                            pinfo.Price = Convert.ToInt32(t14.Text);
                            pinfo.Brand = t15.Text;
                            pinfo.Qualtity = Convert.ToInt32(t16.Text);
                            pinfo.BuyPrice = Convert.ToInt32(t17.Text);
                            pinfo.Picture = pic;
                            int rc1 = uop.InsertProcessorFeature(pinfo);
                            if (rc1 > 0)
                            {
                                MessageBox.Show("Product Added");
                            }
                        }
                        else if (comboBox3.Text=="MotherBoard")
                        {
                            l9.Text = "Supported Cpu:";
                            l12.Text = "RAM Type:";
                            l13.Text = "RAM Max:";
                            l14.Text = "LAN ChipSet";
                            l15.Text = "USB";
                            l16.Text = "Saling Price";
                            l17.Text = "Parts Id";
                            l18.Text = "Quantity";
                            l19.Text = "Buying Price";
                            mbinfo.ProductId = Convert.ToInt32(t1.Text);
                            mbinfo.Model = t2.Text;
                            mbinfo.CpuSocket = t3.Text;
                            mbinfo.Graphic = t4.Text;
                            mbinfo.AudioChipSet = t5.Text;
                            mbinfo.VGA = t6.Text;
                            mbinfo.BiosType = t7.Text;
                            mbinfo.BiosModel = t8.Text;
                            mbinfo.SupportedCpu = t9.Text;
                            mbinfo.RAMType = t12.Text;
                            mbinfo.RAMMax = t13.Text;
                            mbinfo.LanChipSat = t14.Text;
                            mbinfo.USB = t15.Text;
                            mbinfo.Price = Convert.ToInt32(t16.Text);
                            mbinfo.PartsId = Convert.ToInt32(t17.Text);
                            mbinfo.Quantity = Convert.ToInt32(t18.Text);
                            mbinfo.BuyPrice = Convert.ToInt32(t19.Text);
                            int rc1 = uop.InsertMainBoardFeature(mbinfo);
                            if (rc1 > 0)
                            {
                                MessageBox.Show("Product Added");
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Product can not add you must fill all the information");
            }
        }
    }
}
