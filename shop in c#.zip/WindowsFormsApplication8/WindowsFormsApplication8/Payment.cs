﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Access;
using Business_Emplementation;

namespace WindowsFormsApplication8
{
    public partial class Payment : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        UserOperation uop = new UserOperation();
        DataTable dt = new DataTable();
        DataTable dt1 = new DataTable();
         Business_Emplementation.Order o = new Business_Emplementation.Order();
        SaleHistory s = new SaleHistory();

        string order=null;
        public Payment()
        {
            InitializeComponent();
            if (Login.logintype == "admin")
            {
                this.button1.Visible = true;
            }
            else
                this.button1.Visible = false;
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Hide();
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Desktop d1 = new Desktop();
            this.Hide();
            d1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Laptop l1 = new Laptop();
            this.Hide();
            l1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mobile m1 = new Mobile();
            this.Hide();
            m1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tablate l1 = new Tablate();
            this.Hide();
            l1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Login")
            {
                Login l1 = new Login();
                this.Hide();
                l1.Show();
            }
            else if (label1.Text == "Logout")
            {
                this.label1.Text = "Login";
                Login.isLogin = false;
                Login.logintype = null;
                button1.Visible = false;
                Form1 f1 = new Form1();
                this.Hide();
                f1.Show();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminPanel ap = new AdminPanel();
            this.Hide();
            ap.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Chart c = new Chart();
            this.Hide();
            c.Show();
        }

        internal void ReciveChart(DataTable d)
        {
            dt = d;
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox2.Text== "Cradit Card")
            {
                label8.Visible = true;
                textBox4.Visible = true;
            }
            else
            {
                label8.Visible = false;
                textBox4.Visible = false;
            }
        }

        internal void AdminHistory(DataTable d1)
        {
            dt1 = d1;
        }

        private void button9_Click(object sender, EventArgs e)
        {
           if(comboBox2.Text=="Cradit Card")
            {
                if(textBox4.Text!=null&&textBox2.Text!=null&&textBox3.Text!=null)
                {
                    DialogResult dl = MessageBox.Show("Are you sure ...", "Conformation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dl == DialogResult.Yes)
                    {
                        for(int i =0;i<dt.Rows.Count;i++)
                        {
                            order += dt.Rows[i][0].ToString() + "[" + dt.Rows[i][1].ToString() + "] "; 
                        }
                        s.Time = DateTime.Now.Date;
                        s.Sales = dt1.Rows[0][0].ToString();
                        int rc3 = uop.InsertTodaySalesReport(s);
                        o.Time = DateTime.Now.Date;
                        o.Orders = order;
                        o.Address = textBox3.Text;
                        int rc = uop.InsertToOrder(o);
                        if(rc>0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                string pid = dt.Rows[i][0].ToString();
                                pid.Substring(0, 2);
                                if (pid.Substring(0, 2) == "10")
                                {
                                    int rc1 = uop.CheckOut10(pid, dt.Rows[i][1].ToString());
                                }
                                else if (pid.Substring(0, 2) == "20")
                                {
                                    int rc1 = uop.CheckOut20(pid, dt.Rows[i][1].ToString());
                                }
                                else if (pid.Substring(0, 2) == "30")
                                {
                                    int rc1 = uop.CheckOut30(pid, dt.Rows[i][1].ToString());
                                }
                                else if (pid.Substring(0, 2) == "40")
                                {
                                    int rc1 = uop.CheckOut40(pid, dt.Rows[i][1].ToString());
                                }
                            }
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                string pid = dt.Rows[i][0].ToString();
                                int rc1 = uop.DeleteChart(pid);
                            }
                        }
                    }
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
