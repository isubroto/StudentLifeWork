﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Access;
using Business_Emplementation;

namespace WindowsFormsApplication8
{
    public partial class Register : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
    public const int HT_CAPTION = 0x2;

    [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
    [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
    public static extern bool ReleaseCapture();
        UserInformation uinfo = new UserInformation();
        UserOperation uop = new UserOperation();
        public Register()
        {
            InitializeComponent();
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Desktop d1 = new Desktop();
            this.Hide();
            d1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Laptop l1 = new Laptop();
            this.Hide();
            l1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mobile m1 = new Mobile();
            this.Hide();
            m1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tablate t1 = new Tablate();
            this.Hide();
            t1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Login")
            {
                Login l1 = new Login();
                this.Hide();
                l1.Show();
            }
            else if (label1.Text == "Logout")
            {
                this.label1.Text = "Login";
                Login.isLogin = false;
                Login.logintype = null;
            };

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(textBox3.Text==textBox4.Text)
            {
                uinfo.Name = textBox2.Text;
                uinfo.UserName = textBox3.Text;
                uinfo.Password = textBox4.Text;
                uinfo.Email = textBox6.Text;
                uinfo.Phone = textBox7.Text;
                if (this.radioButton1.Checked == true)
                {
                    uinfo.Gender = "Male";
                }
                else if (this.radioButton2.Checked == true)
                {
                    uinfo.Gender = "Female";
                }
                int row = uop.insertuser(uinfo);
                if (row > 0)
                {
                    MessageBox.Show("Register Successfull");
                }
                else
                {
                    MessageBox.Show("This User Name is not available");
                }
            }
            else
            {
                MessageBox.Show("Password does not match");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
