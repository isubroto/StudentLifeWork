﻿namespace WindowsFormsApplication8
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProduct));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.path1 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.l20 = new System.Windows.Forms.Label();
            this.l9 = new System.Windows.Forms.Label();
            this.t20 = new System.Windows.Forms.TextBox();
            this.t9 = new System.Windows.Forms.TextBox();
            this.l19 = new System.Windows.Forms.Label();
            this.l8 = new System.Windows.Forms.Label();
            this.t19 = new System.Windows.Forms.TextBox();
            this.t8 = new System.Windows.Forms.TextBox();
            this.l18 = new System.Windows.Forms.Label();
            this.l7 = new System.Windows.Forms.Label();
            this.t18 = new System.Windows.Forms.TextBox();
            this.t7 = new System.Windows.Forms.TextBox();
            this.l17 = new System.Windows.Forms.Label();
            this.l6 = new System.Windows.Forms.Label();
            this.t17 = new System.Windows.Forms.TextBox();
            this.t6 = new System.Windows.Forms.TextBox();
            this.l16 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.t16 = new System.Windows.Forms.TextBox();
            this.t5 = new System.Windows.Forms.TextBox();
            this.l15 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.t15 = new System.Windows.Forms.TextBox();
            this.t4 = new System.Windows.Forms.TextBox();
            this.l14 = new System.Windows.Forms.Label();
            this.l3 = new System.Windows.Forms.Label();
            this.t14 = new System.Windows.Forms.TextBox();
            this.t3 = new System.Windows.Forms.TextBox();
            this.l13 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.t13 = new System.Windows.Forms.TextBox();
            this.t2 = new System.Windows.Forms.TextBox();
            this.l12 = new System.Windows.Forms.Label();
            this.t12 = new System.Windows.Forms.TextBox();
            this.l1 = new System.Windows.Forms.Label();
            this.t1 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(813, 80);
            this.panel1.TabIndex = 4;
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // label6
            // 
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.Location = new System.Drawing.Point(349, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 28);
            this.label6.TabIndex = 6;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(774, 6);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(27, 23);
            this.button8.TabIndex = 5;
            this.button8.Text = "X";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(580, 49);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(99, 20);
            this.textBox1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(676, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 28);
            this.label2.TabIndex = 3;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(481, 48);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(93, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(392, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Catagory";
            // 
            // label1
            // 
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(716, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Login";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(747, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(27, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "–";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 80);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(120, 405);
            this.panel2.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(0, 245);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 48);
            this.button1.TabIndex = 1;
            this.button1.Text = "AdminPanel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button3_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(0, 195);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(120, 48);
            this.button3.TabIndex = 1;
            this.button3.Text = "Tablet";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(1, 146);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 48);
            this.button7.TabIndex = 2;
            this.button7.Text = "Mobile";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(1, 98);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(120, 48);
            this.button6.TabIndex = 3;
            this.button6.Text = "Laptop";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(1, 50);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 48);
            this.button5.TabIndex = 4;
            this.button5.Text = "Desktop";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(1, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 48);
            this.button4.TabIndex = 5;
            this.button4.Text = "Home";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label4
            // 
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(263, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "Collection";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(371, 87);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(105, 21);
            this.comboBox2.TabIndex = 2;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(595, 89);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(103, 21);
            this.comboBox3.TabIndex = 2;
            this.comboBox3.Visible = false;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(517, 89);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 25);
            this.label5.TabIndex = 1;
            this.label5.Text = "Parts";
            this.label5.Visible = false;
            // 
            // label7
            // 
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(263, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "Picture : ";
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button9.Location = new System.Drawing.Point(595, 123);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(112, 23);
            this.button9.TabIndex = 6;
            this.button9.Text = "Choose";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(122, 98);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // path1
            // 
            this.path1.Location = new System.Drawing.Point(333, 123);
            this.path1.Multiline = true;
            this.path1.Name = "path1";
            this.path1.ReadOnly = true;
            this.path1.Size = new System.Drawing.Size(256, 20);
            this.path1.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button10);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.l20);
            this.panel3.Controls.Add(this.l9);
            this.panel3.Controls.Add(this.t20);
            this.panel3.Controls.Add(this.t9);
            this.panel3.Controls.Add(this.l19);
            this.panel3.Controls.Add(this.l8);
            this.panel3.Controls.Add(this.t19);
            this.panel3.Controls.Add(this.t8);
            this.panel3.Controls.Add(this.l18);
            this.panel3.Controls.Add(this.l7);
            this.panel3.Controls.Add(this.t18);
            this.panel3.Controls.Add(this.t7);
            this.panel3.Controls.Add(this.l17);
            this.panel3.Controls.Add(this.l6);
            this.panel3.Controls.Add(this.t17);
            this.panel3.Controls.Add(this.t6);
            this.panel3.Controls.Add(this.l16);
            this.panel3.Controls.Add(this.l5);
            this.panel3.Controls.Add(this.t16);
            this.panel3.Controls.Add(this.t5);
            this.panel3.Controls.Add(this.l15);
            this.panel3.Controls.Add(this.l4);
            this.panel3.Controls.Add(this.t15);
            this.panel3.Controls.Add(this.t4);
            this.panel3.Controls.Add(this.l14);
            this.panel3.Controls.Add(this.l3);
            this.panel3.Controls.Add(this.t14);
            this.panel3.Controls.Add(this.t3);
            this.panel3.Controls.Add(this.l13);
            this.panel3.Controls.Add(this.l2);
            this.panel3.Controls.Add(this.t13);
            this.panel3.Controls.Add(this.t2);
            this.panel3.Controls.Add(this.l12);
            this.panel3.Controls.Add(this.t12);
            this.panel3.Controls.Add(this.l1);
            this.panel3.Controls.Add(this.t1);
            this.panel3.Location = new System.Drawing.Point(120, 80);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(692, 404);
            this.panel3.TabIndex = 8;
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(211, 359);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(261, 34);
            this.button10.TabIndex = 8;
            this.button10.Text = "Add";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Visible = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // l20
            // 
            this.l20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l20.Location = new System.Drawing.Point(328, 320);
            this.l20.Name = "l20";
            this.l20.Size = new System.Drawing.Size(117, 25);
            this.l20.TabIndex = 1;
            this.l20.Text = "l1";
            this.l20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l20.Visible = false;
            // 
            // l9
            // 
            this.l9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l9.Location = new System.Drawing.Point(34, 317);
            this.l9.Name = "l9";
            this.l9.Size = new System.Drawing.Size(112, 25);
            this.l9.TabIndex = 1;
            this.l9.Text = "l1";
            this.l9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l9.Visible = false;
            // 
            // t20
            // 
            this.t20.Location = new System.Drawing.Point(459, 322);
            this.t20.Multiline = true;
            this.t20.Name = "t20";
            this.t20.Size = new System.Drawing.Size(150, 20);
            this.t20.TabIndex = 4;
            this.t20.Visible = false;
            // 
            // t9
            // 
            this.t9.Location = new System.Drawing.Point(160, 319);
            this.t9.Multiline = true;
            this.t9.Name = "t9";
            this.t9.Size = new System.Drawing.Size(150, 20);
            this.t9.TabIndex = 4;
            this.t9.Visible = false;
            // 
            // l19
            // 
            this.l19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l19.Location = new System.Drawing.Point(329, 295);
            this.l19.Name = "l19";
            this.l19.Size = new System.Drawing.Size(117, 25);
            this.l19.TabIndex = 1;
            this.l19.Text = "l1";
            this.l19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l19.Visible = false;
            // 
            // l8
            // 
            this.l8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l8.Location = new System.Drawing.Point(35, 292);
            this.l8.Name = "l8";
            this.l8.Size = new System.Drawing.Size(112, 25);
            this.l8.TabIndex = 1;
            this.l8.Text = "l1";
            this.l8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l8.Visible = false;
            // 
            // t19
            // 
            this.t19.Location = new System.Drawing.Point(460, 297);
            this.t19.Multiline = true;
            this.t19.Name = "t19";
            this.t19.Size = new System.Drawing.Size(150, 20);
            this.t19.TabIndex = 4;
            this.t19.Visible = false;
            // 
            // t8
            // 
            this.t8.Location = new System.Drawing.Point(161, 294);
            this.t8.Multiline = true;
            this.t8.Name = "t8";
            this.t8.Size = new System.Drawing.Size(150, 20);
            this.t8.TabIndex = 4;
            this.t8.Visible = false;
            // 
            // l18
            // 
            this.l18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l18.Location = new System.Drawing.Point(329, 270);
            this.l18.Name = "l18";
            this.l18.Size = new System.Drawing.Size(117, 25);
            this.l18.TabIndex = 1;
            this.l18.Text = "l1";
            this.l18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l18.Visible = false;
            // 
            // l7
            // 
            this.l7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l7.Location = new System.Drawing.Point(35, 267);
            this.l7.Name = "l7";
            this.l7.Size = new System.Drawing.Size(112, 25);
            this.l7.TabIndex = 1;
            this.l7.Text = "l1";
            this.l7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l7.Visible = false;
            // 
            // t18
            // 
            this.t18.Location = new System.Drawing.Point(460, 272);
            this.t18.Multiline = true;
            this.t18.Name = "t18";
            this.t18.Size = new System.Drawing.Size(150, 20);
            this.t18.TabIndex = 4;
            this.t18.Visible = false;
            // 
            // t7
            // 
            this.t7.Location = new System.Drawing.Point(161, 269);
            this.t7.Multiline = true;
            this.t7.Name = "t7";
            this.t7.Size = new System.Drawing.Size(150, 20);
            this.t7.TabIndex = 4;
            this.t7.Visible = false;
            // 
            // l17
            // 
            this.l17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l17.Location = new System.Drawing.Point(329, 245);
            this.l17.Name = "l17";
            this.l17.Size = new System.Drawing.Size(117, 25);
            this.l17.TabIndex = 1;
            this.l17.Text = "l1";
            this.l17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l17.Visible = false;
            // 
            // l6
            // 
            this.l6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l6.Location = new System.Drawing.Point(35, 242);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(112, 25);
            this.l6.TabIndex = 1;
            this.l6.Text = "l1";
            this.l6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l6.Visible = false;
            // 
            // t17
            // 
            this.t17.Location = new System.Drawing.Point(460, 247);
            this.t17.Multiline = true;
            this.t17.Name = "t17";
            this.t17.Size = new System.Drawing.Size(150, 20);
            this.t17.TabIndex = 4;
            this.t17.Visible = false;
            // 
            // t6
            // 
            this.t6.Location = new System.Drawing.Point(161, 244);
            this.t6.Multiline = true;
            this.t6.Name = "t6";
            this.t6.Size = new System.Drawing.Size(150, 20);
            this.t6.TabIndex = 4;
            this.t6.Visible = false;
            // 
            // l16
            // 
            this.l16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l16.Location = new System.Drawing.Point(329, 220);
            this.l16.Name = "l16";
            this.l16.Size = new System.Drawing.Size(117, 25);
            this.l16.TabIndex = 1;
            this.l16.Text = "l1";
            this.l16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l16.Visible = false;
            // 
            // l5
            // 
            this.l5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l5.Location = new System.Drawing.Point(35, 217);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(112, 25);
            this.l5.TabIndex = 1;
            this.l5.Text = "l1";
            this.l5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l5.Visible = false;
            // 
            // t16
            // 
            this.t16.Location = new System.Drawing.Point(460, 222);
            this.t16.Multiline = true;
            this.t16.Name = "t16";
            this.t16.Size = new System.Drawing.Size(150, 20);
            this.t16.TabIndex = 4;
            this.t16.Visible = false;
            // 
            // t5
            // 
            this.t5.Location = new System.Drawing.Point(161, 219);
            this.t5.Multiline = true;
            this.t5.Name = "t5";
            this.t5.Size = new System.Drawing.Size(150, 20);
            this.t5.TabIndex = 4;
            this.t5.Visible = false;
            // 
            // l15
            // 
            this.l15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l15.Location = new System.Drawing.Point(329, 195);
            this.l15.Name = "l15";
            this.l15.Size = new System.Drawing.Size(117, 25);
            this.l15.TabIndex = 1;
            this.l15.Text = "l1";
            this.l15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l15.Visible = false;
            // 
            // l4
            // 
            this.l4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l4.Location = new System.Drawing.Point(35, 192);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(112, 25);
            this.l4.TabIndex = 1;
            this.l4.Text = "l1";
            this.l4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l4.Visible = false;
            // 
            // t15
            // 
            this.t15.Location = new System.Drawing.Point(460, 197);
            this.t15.Multiline = true;
            this.t15.Name = "t15";
            this.t15.Size = new System.Drawing.Size(150, 20);
            this.t15.TabIndex = 4;
            this.t15.Visible = false;
            // 
            // t4
            // 
            this.t4.Location = new System.Drawing.Point(161, 194);
            this.t4.Multiline = true;
            this.t4.Name = "t4";
            this.t4.Size = new System.Drawing.Size(150, 20);
            this.t4.TabIndex = 4;
            this.t4.Visible = false;
            // 
            // l14
            // 
            this.l14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l14.Location = new System.Drawing.Point(329, 170);
            this.l14.Name = "l14";
            this.l14.Size = new System.Drawing.Size(117, 25);
            this.l14.TabIndex = 1;
            this.l14.Text = "l1";
            this.l14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l14.Visible = false;
            // 
            // l3
            // 
            this.l3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l3.Location = new System.Drawing.Point(35, 167);
            this.l3.Name = "l3";
            this.l3.Size = new System.Drawing.Size(112, 25);
            this.l3.TabIndex = 1;
            this.l3.Text = "l1";
            this.l3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l3.Visible = false;
            // 
            // t14
            // 
            this.t14.Location = new System.Drawing.Point(460, 172);
            this.t14.Multiline = true;
            this.t14.Name = "t14";
            this.t14.Size = new System.Drawing.Size(150, 20);
            this.t14.TabIndex = 4;
            this.t14.Visible = false;
            // 
            // t3
            // 
            this.t3.Location = new System.Drawing.Point(161, 169);
            this.t3.Multiline = true;
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(150, 20);
            this.t3.TabIndex = 4;
            this.t3.Visible = false;
            // 
            // l13
            // 
            this.l13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l13.Location = new System.Drawing.Point(329, 138);
            this.l13.Name = "l13";
            this.l13.Size = new System.Drawing.Size(117, 25);
            this.l13.TabIndex = 1;
            this.l13.Text = "l1";
            this.l13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l13.Visible = false;
            // 
            // l2
            // 
            this.l2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l2.Location = new System.Drawing.Point(35, 135);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(112, 25);
            this.l2.TabIndex = 1;
            this.l2.Text = "l1";
            this.l2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l2.Visible = false;
            // 
            // t13
            // 
            this.t13.Location = new System.Drawing.Point(460, 140);
            this.t13.Multiline = true;
            this.t13.Name = "t13";
            this.t13.Size = new System.Drawing.Size(150, 20);
            this.t13.TabIndex = 4;
            this.t13.Visible = false;
            // 
            // t2
            // 
            this.t2.Location = new System.Drawing.Point(161, 137);
            this.t2.Multiline = true;
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(150, 20);
            this.t2.TabIndex = 4;
            this.t2.Visible = false;
            // 
            // l12
            // 
            this.l12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l12.Location = new System.Drawing.Point(328, 109);
            this.l12.Name = "l12";
            this.l12.Size = new System.Drawing.Size(117, 25);
            this.l12.TabIndex = 1;
            this.l12.Text = "l1";
            this.l12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l12.Visible = false;
            // 
            // t12
            // 
            this.t12.Location = new System.Drawing.Point(459, 112);
            this.t12.Multiline = true;
            this.t12.Name = "t12";
            this.t12.Size = new System.Drawing.Size(151, 20);
            this.t12.TabIndex = 4;
            this.t12.Visible = false;
            // 
            // l1
            // 
            this.l1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l1.Location = new System.Drawing.Point(34, 106);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(112, 25);
            this.l1.TabIndex = 1;
            this.l1.Text = "l1";
            this.l1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.l1.Visible = false;
            // 
            // t1
            // 
            this.t1.Location = new System.Drawing.Point(160, 109);
            this.t1.Multiline = true;
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(151, 20);
            this.t1.TabIndex = 4;
            this.t1.Visible = false;
            // 
            // AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 485);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.path1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AddProduct";
            this.Load += new System.EventHandler(this.AddProduct_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox path1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label l9;
        private System.Windows.Forms.TextBox t9;
        private System.Windows.Forms.Label l8;
        private System.Windows.Forms.TextBox t8;
        private System.Windows.Forms.Label l7;
        private System.Windows.Forms.TextBox t7;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.TextBox t6;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.TextBox t5;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.TextBox t4;
        private System.Windows.Forms.Label l3;
        private System.Windows.Forms.TextBox t3;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.TextBox t2;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.TextBox t1;
        private System.Windows.Forms.Label l20;
        private System.Windows.Forms.TextBox t20;
        private System.Windows.Forms.Label l19;
        private System.Windows.Forms.TextBox t19;
        private System.Windows.Forms.Label l18;
        private System.Windows.Forms.TextBox t18;
        private System.Windows.Forms.Label l17;
        private System.Windows.Forms.TextBox t17;
        private System.Windows.Forms.Label l16;
        private System.Windows.Forms.TextBox t16;
        private System.Windows.Forms.Label l15;
        private System.Windows.Forms.TextBox t15;
        private System.Windows.Forms.Label l14;
        private System.Windows.Forms.TextBox t14;
        private System.Windows.Forms.Label l13;
        private System.Windows.Forms.TextBox t13;
        private System.Windows.Forms.Label l12;
        private System.Windows.Forms.TextBox t12;
        private System.Windows.Forms.Button button10;
    }
}