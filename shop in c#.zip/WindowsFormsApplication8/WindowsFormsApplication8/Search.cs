﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Access;

namespace WindowsFormsApplication8
{
    public partial class Search : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        protected Button[] bt = new Button[10000];
        protected PictureBox[] pb = new PictureBox[10000];
        protected Label[] lv = new Label[10000];
        UserOperation uop = new UserOperation();
        DataTable dt = new DataTable();
        String catagory;
        String path = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
        public Search()
        {
            InitializeComponent();
            if (Login.logintype == "admin")
            {
                this.button1.Visible = true;
            }
            else
                this.button1.Visible = false;
            if (Login.isLogin == true)
            {
                label1.Text = "Logout";
                label6.Visible = true;
            }
            else
            {
                label6.Visible = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Hide();
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Desktop d1 = new Desktop();
            this.Hide();
            d1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Laptop l1 = new Laptop();
            this.Hide();
            l1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mobile m1 = new Mobile();
            this.Hide();
            m1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tablate l1 = new Tablate();
            this.Hide();
            l1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Login")
            {
                Login l1 = new Login();
                this.Hide();
                l1.Show();
            }
            else if (label1.Text == "Logout")
            {
                this.label1.Text = "Login";
                Login.isLogin = false;
                Login.logintype = null;
                label6.Visible = false;
                button1.Visible = false;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminPanel ap = new AdminPanel();
            this.Hide();
            ap.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Chart c = new Chart();
            this.Hide();
            c.Show();
        }
        private void Viewdetails(object sender, EventArgs e)
        {
            if(catagory=="Mobile")
            {
                this.ViewdetailsMobile(sender, e);
            }
            else if(catagory=="Laptop")
            {
                this.ViewdetailsLaptop(sender, e);
            }
            else if(catagory=="Tablet")
            {
                this.ViewdetailsTablet(sender, e);
            }
            else if(catagory=="HDD")
            {
                this.ShowHDD(sender, e);
            }
            else if(catagory=="RAM")
            {
                this.ShowRAM(sender, e);
            }
            else if(catagory=="Processor")
            {
                this.ShowProcessor(sender, e);
            }
            else if(catagory=="MotherBoard")
            {
                this.ShowMotherBoard(sender, e);
            }
        }
        private void ViewdetailsTablet(object sender, EventArgs e)
        {
            Details d = new Details();
            Button b = (Button)sender;
            dt = uop.ViewTablet(b.Text);
            d.senddetails(dt);
            this.Hide();
            d.Show();
        }
        private void ShowMotherBoard(object sender, EventArgs e)
        {
            Details d = new Details();
            Button b = (Button)sender;
            dt = uop.ViewMotherboard(b.Text);
            d.senddetailsMotherboard(dt);
            this.Hide();
            d.Show();
        }

        private void ShowProcessor(object sender, EventArgs e)
        {
            Details d = new Details();
            Button b = (Button)sender;
            dt = uop.ViewProcessor(b.Text);
            d.senddetailsProcessor(dt);
            this.Hide();
            d.Show();
        }

        private void ShowRAM(object sender, EventArgs e)
        {
            Details d = new Details();
            Button b = (Button)sender;
            dt = uop.ViewRAM(b.Text);
            d.senddetailsRAM(dt);
            this.Hide();
            d.Show();
        }

        private void ShowHDD(object sender, EventArgs e)
        {
            Details d = new Details();
            Button b = (Button)sender;
            dt = uop.ViewHDD(b.Text);
            d.senddetailsHDD(dt);
            this.Hide();
            d.Show();
        }
        private void ViewdetailsMobile(object sender, EventArgs e)
        {
            Details d = new Details();
            Button b = (Button)sender;
            dt = uop.ViewMobile(b.Text);
            d.senddetails(dt);
            this.Hide();
            d.Show();
        }
        private void ViewdetailsLaptop(object sender, EventArgs e)
        {
            Details d = new Details();
            Button b = (Button)sender;
            dt = uop.ViewLaptop(b.Text);
            d.senddetails(dt);
            this.Hide();
            d.Show();
        }
        private void clear()
        {
            for (int i = 0; i < 10000; i++)
            {
                this.Controls.Remove(bt[i]);
                this.Controls.Remove(lv[i]);
                this.Controls.Remove(pb[i]);
            }
        }
        private void Search_Load(object sender, EventArgs e)
        {
            clear();
            int x = 154, y = 140;
            dt = uop.ShowLaptop();
            int rc = dt.Rows.Count;
            for (int i = 0; i < rc; i++)
            {
                lv[i] = new Label();
                lv[i].Visible = true;
                lv[i].AutoSize = false;
                lv[i].TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                lv[i].Location = new System.Drawing.Point(x, y + 66);
                lv[i].Size = new System.Drawing.Size(100, 22);
                pb[i] = new PictureBox();
                pb[i].Visible = true;
                pb[i].Location = new System.Drawing.Point(x, y);
                pb[i].SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                pb[i].Size = new System.Drawing.Size(100, 66);
                pb[i].TabStop = false;
                bt[i] = new Button();
                bt[i].Location = new System.Drawing.Point(x, y + 91);
                bt[i].Size = new System.Drawing.Size(100, 23);
                bt[i].TabIndex = i;
                bt[i].Visible = true;
                bt[i].UseVisualStyleBackColor = true;
                bt[i].FlatAppearance.BorderSize = 0;
                bt[i].FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                bt[i].ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
                lv[i].Text = dt.Rows[i][1].ToString();
                pb[i].Image = Image.FromFile(path + dt.Rows[i][2]);
                bt[i].Text = dt.Rows[i][0].ToString();
                bt[i].Click += new System.EventHandler(this.Viewdetails);
                this.Controls.Add(pb[i]);
                this.Controls.Add(bt[i]);
                this.Controls.Add(lv[i]);
                x += 134;
                if (x > 750)
                {
                    y += 130;
                    x = 154;
                }
            }
        }

        internal void ReciveData(DataTable dt1, String text)
        {
            dt = dt1;
            catagory = text;
        }
    }
}
