﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class HDDInformation
    {
        public int ProductId
            {set;get;}
        public string Model
        { set; get; }
        public string Brand
        { set; get; }
        public string Type
        { set; get; }
        public string RPM
        { set; get; }
        public string Capacity
        { set; get; }
        public string Picture
        { set; get; }
        public int Price
        { set; get; }
        public int PartsId
        { set; get; }
        public int Qantuty
        { set; get; }
        public int BuyPrice { get; set; }
    }
}
