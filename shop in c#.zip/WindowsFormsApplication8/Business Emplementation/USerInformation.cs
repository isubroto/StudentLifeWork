﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class UserInformation
    {
        public String Name
        {
            set;
            get;
        }
        public String UserName
        {
            set;
            get;
        }
        public String Password
        {
            set;
            get;
        }
        public String Email
        {
            set;
            get;
        }
        public String Phone
        {
            set;
            get;
        }
        public String Gender
        {
            set;
            get;
        }
        public String Type
        {
            set;
            get;
        }
    }
}
