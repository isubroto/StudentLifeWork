﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class ProductInformation
    {
        public int ProductId
        { set; get; }
        public String ProductName
        { set; get; }

    }
}
