﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class MothetboardInformation
    {
        public string AudioChipSet { get; set; }
        public string BiosModel { get; set; }
        public string BiosType { get; set; }
        public int BuyPrice { get; set; }
        public string CpuSocket { get; set; }
        public string Graphic { get; set; }
        public string LanChipSat { get; set; }
        public string Model { get; set; }
        public int PartsId { get; set; }
        public int Price { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public string RAMMax { get; set; }
        public string RAMType { get; set; }
        public string SupportedCpu { get; set; }
        public string USB { get; set; }
        public string VGA { get; set; }
    }
}
