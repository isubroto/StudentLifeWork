﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class SaleHistory
    {
        public string Sales { get; set; }
        public DateTime Time { get; set; }
    }
}
