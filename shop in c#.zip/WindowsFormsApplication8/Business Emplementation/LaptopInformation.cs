﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
   public class LaptopInformation
    {
        public int ProductId
        { set; get; }
        public String Model
        { set; get; }
        public String DsplaySize
        { set; get; }
        public String Network
        { set; get; }
        public String RAM
        { set; get; }
        public String USB
        { set; get; }
        public String Battery
        { set; get; }
        public String ClockSpeed
        { set; get; }
        public String OpricalDrive
        { set; get; }
        public String RAMType
        { set; get; }
        public String OS
        { set; get; }
        public String Processor
        { set; get; }
        public String HDD
        { set; get; }
        public String SSD
        { set; get; }
        public int Price
        { set; get; }
        public String Brandid
        { set; get; }
        public int Quantity
        { set; get; }
        public Byte[] Picture
        { set; get; }
    }
}
