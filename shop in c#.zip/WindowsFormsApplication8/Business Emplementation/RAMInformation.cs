﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class RAMInformation
    {
        public int ProductId
        { set; get; }
        public string Brand
        { set; get; }
        public string BusSpeed
        { set; get; }
        public string Type
        { set; get; }
        public string Capacity
        { set; get; }
        public string Model
        { set; get; }
        public int Price
        { set; get; }
        public int PartsId
        { set; get; }
        public string Picure
        { set; get; }
        public int Qualtity
        { set; get; }
        public int BuyPrice { get; set; }
    }
}
