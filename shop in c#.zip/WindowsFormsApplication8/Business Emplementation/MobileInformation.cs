﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class MobileInformation
    {
        public int ProductId
        { set; get; }
        public String Model
        { set; get; }
        public String DsplaySize
        { set; get; }
        public String Tecnology
        { set; get; }
        public String DisplayType
        { set; get; }
        public String USB
        { set; get; }
        public String Battery
        { set; get; }
        public String Memory
        { set; get; }
        public String Conectivity
        { set; get; }
        public String Video
        { set; get; }
        public String OS
        { set; get; }
        public String CPU
        { set; get; }
        public String GPU
        { set; get; }
        public String ChipSet
        { set; get; }
        public int Price
        { set; get; }
        public int Brandid
        { set; get; }
        public int Quantity
        { set; get; }
        public String Picture
        { set; get; }
        public int BuyPrice
        { set; get; }
    }
}
