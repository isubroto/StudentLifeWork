﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Emplementation
{
    public class ProcessorInformation
    {
       public int  ProductId
        { set; get; }
       public string Model
        { set; get; }
        public string Genaration
        { set; get; }
        public string NumberOfCore
        { set; get; }
        public string CashMemory
        { set; get; }
        public int PartsId
        { set; get; }
        public string Turbo
        { set; get; }
        public int Price
        { set; get; }
        public string Brand
        { set; get; }
        public int Qualtity
        { set; get; }
        public string Picture
        { set; get; }
        public int BuyPrice { get; set; }
    }
}
