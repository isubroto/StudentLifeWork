﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;

namespace Buisness
{
    public class User
    {

        
        private String name;
        private String userName;
        private String password;
        private String email;
        private String phone;
        private String gender;
        private String type;

        Data d = new Data();
        
        public User()
        {
            this.name = this.userName = this.password = this.email = this.phone = this.gender = this.type = null;
        }
        public String Name
        {
            set { this.name = value; }
            get { return this.name; }
        }
        public String UserName
        {
            set { this.userName = value; }
            get { return this.userName; }
        }
        public String Password
        {
            set { this.password = value; }
            get { return this.password; }
        }
        public String Email
        {
            set { this.email = value; }
            get { return this.email; }
        }
        public String Phone
        {
            set { this.phone = value; }
            get { return this.phone; }
        }
        public String Gender
        {
            set { this.gender = value; }
            get { return this.gender; }
        }
        public String Type
        {
            set { this.type = value; }
            get { return this.type; }
        }
        public void Login(String u,String p,String t)
        {
            d.LoginInfo(userName,u,p,t);
            if(userName!=null)
            {
                u = userName;
                
            }
        }

    }
}
