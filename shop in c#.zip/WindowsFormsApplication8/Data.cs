﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DataAccess
{
    public class Data
    {
        public static Database db = new Database(@"Data Source=ANMONA;Initial Catalog=OnlineShoping;Integrated Security=True");
       public void LoginInfo(String u,String n,String p,String t)
        {
            User u1 = null;
            u1 = db.Users.Single(un => un.UserName == n && un.Password == p);
            if (u1!= null)
            {
                u = u1.UserName;
                t = u1.Type;
            }
        }

    }
}
