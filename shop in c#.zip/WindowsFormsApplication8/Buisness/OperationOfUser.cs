﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using DataAccess;
using Business_Emplementation;
using System.IO;
using System.Drawing;

namespace Business_Access
{
    public class UserOperation
    {




        Data d = new Data();
        UserInformation info = new UserInformation();

        public int insertuser(UserInformation uinfo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [dbo].[User] ([Name], [UserName], [Email], [Password], [Phone], [Gender], [Type]) VALUES (N'" + uinfo.Name + "', N'" + uinfo.UserName + "', N'" + uinfo.Password + "', N'" + uinfo.Email + "', N'" + uinfo.Phone + "', N'" + uinfo.Gender + "', N'user')";
            return d.ExeNonQuery(cmd);
        }

        public DataTable Login(UserInformation uinfo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [dbo].[User] where [UserName] = N'" + uinfo.UserName + "' and [Password] =N'" + uinfo.Password + "';";
            return d.ExeReader(cmd);
        }

        public DataTable GetCatagory()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select ProductName from dbo.Product ";
            return d.ExeReader(cmd);
        }

        public DataTable GetParts()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select PartsName from dbo.Desktop";
            return d.ExeReader(cmd);
        }

        public int InsertMobileFeature(MobileInformation m)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [dbo].[MobileFeature] ([ProdutId], [Model], [DisplaySize], [Technology], [DisplayType], [USB], [Battery], [Memory], [Conectivity], [Video], [OS], [CPU], [GPU], [ChipSet], [Price], [BrandId], [Quantity], [Picture], [Buy]) VALUES (N'" + m.ProductId + "', N'" + m.Model + "', N'" + m.DsplaySize + "', N'" + m.Tecnology + "', N'" + m.DisplayType + "', N'" + m.USB + "', N'" + m.Battery + "', N'" + m.Memory + "', N'" + m.Conectivity + "', N'" + m.Video + "', N'" + m.OS + "', N'" + m.CPU + "', N'" + m.GPU + "', N'" + m.ChipSet + "', N'" + m.Price + "', N'" + m.Brandid + "', N'" + m.Quantity + "', N'" + m.Picture + "', N'" + m.BuyPrice+ "')";
            return d.ExeNonQuery(cmd);
        }

        public int InsertTabletFeature(TabletInformation t)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [dbo].[TabletFeature] ([ProdutId], [Model], [DisplaySize], [Technology], [DisplayType], [USB], [Battery], [Memory], [Conectivity], [Video], [OS], [CPU], [GPU], [ChipSet], [Price], [BrandId], [Quantity], [Picture], [Buy]) VALUES (N'" + t.ProductId + "', N'" + t.Model + "', N'" + t.DsplaySize + "', N'" + t.Tecnology + "', N'" + t.DisplayType + "', N'" + t.USB + "', N'" + t.Battery + "', N'" + t.Memory + "', N'" + t.Conectivity + "', N'" + t.Video + "', N'" + t.OS + "', N'" + t.CPU + "', N'" + t.GPU + "', N'" + t.ChipSet + "', N'" + t.Price + "', N'" + t.Brandid + "', N'" + t.Quantity + "', N'" + t.Picture + "'N'" + t.BuyPrice + "')";
            return d.ExeNonQuery(cmd);
        }

        public int InsertHDDFeature(HDDInformation hinfo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [dbo].[DesktopFeature] ([ProductId], [Brand], [Genaration], [NumberOfCore], [BusSpeed], [Type], [CacheMemory], [Turbo], [RPM], [Capacity], [Model], [Price], [PartsId], [Picture], [Quantity], [Buy]) VALUES (201001, N'" + hinfo.ProductId + "', NULL, NULL, NULL, N'" + hinfo.Type + "', NULL, NULL, N'" + hinfo.RPM + "', N'" + hinfo.Capacity + "', N'" + hinfo.Model + "', " + hinfo.Price + ", " + hinfo.PartsId + ", N'" + hinfo.Picture + "', " + hinfo.Qantuty + "N'" + hinfo.BuyPrice + "')";
            return d.ExeNonQuery(cmd);
        }

        public int InsertRAMFeature(RAMInformation rinfo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [dbo].[DesktopFeature] ([ProductId], [Brand], [Genaration], [NumberOfCore], [BusSpeed], [Type], [CacheMemory], [Turbo], [RPM], [Capacity], [Model], [Price], [PartsId], [Picture], [Quantity], [Buy]) VALUES ("+rinfo.ProductId+", N'"+rinfo.Brand+"', NULL, NULL, N'"+rinfo.BusSpeed+"', N'"+rinfo.Type+"', NULL, NULL, NULL, N'"+rinfo.Capacity+"', N'"+rinfo.Model+"', "+rinfo.Price+", "+rinfo.PartsId+", N'"+rinfo.Picure+"', "+rinfo.Qualtity+ "N'" + rinfo.BuyPrice + "')";
            return d.ExeNonQuery(cmd);
        }

        public int InsertProcessorFeature(ProcessorInformation pinfo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [dbo].[DesktopFeature] ([ProductId], [Brand], [Genaration], [NumberOfCore], [BusSpeed], [Type], [CacheMemory], [Turbo], [RPM], [Capacity], [Model], [Price], [PartsId], [Picture], [Quantity], [Buy]) VALUES ("+pinfo.ProductId+", N'"+pinfo.Brand+"', N'"+pinfo.Genaration+"', N'"+pinfo.NumberOfCore+"', NULL, NULL, N'"+pinfo.CashMemory+"', N'"+pinfo.Turbo+"', NULL, NULL, N'"+pinfo.Model+"', "+pinfo.Price+", "+pinfo.PartsId+", N'"+pinfo.Picture+"', "+pinfo.Qualtity+ "N'" + pinfo.BuyPrice + "')";
            return d.ExeNonQuery(cmd);
        }

        public int InsertMainBoardFeature(MothetboardInformation mbinfo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
           // cmd.CommandText = "INSERT INTO [dbo].[DesktopFeature] ([ProductId], [Brand], [Genaration], [NumberOfCore], [BusSpeed], [Type], [CacheMemory], [Turbo], [RPM], [Capacity], [Model], [Price], [PartsId], [Picture], [Quantity], [Buy]) VALUES (" + pinfo.ProductId + ", N'" + pinfo.Brand + "', N'" + pinfo.Genaration + "', N'" + pinfo.NumberOfCore + "', NULL, NULL, N'" + pinfo.CashMemory + "', N'" + pinfo.Turbo + "', NULL, NULL, N'" + pinfo.Model + "', " + pinfo.Price + ", " + pinfo.PartsId + ", N'" + pinfo.Picture + "', " + pinfo.Qualtity + "N'" + pinfo.BuyPrice + "')";
            return d.ExeNonQuery(cmd);
        }
    }
}
